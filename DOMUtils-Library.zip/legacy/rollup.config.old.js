import resolve from '@rollup/plugin-node-resolve';
import commonjs from '@rollup/plugin-commonjs';
import { terser } from 'rollup-plugin-terser';

/*
  Configuración para generar:
  - dist/index.esm.js  (ESM build principal)
  - dist/index.cjs.js  (CJS build principal)
  - dist/index.umd.js  (UMD minificado)
  - dist/bottom-sheet.esm.js  (ESM chunk que registra <bottom-sheet>)
*/
const input = {
  main: 'src/index.js',
  'bottom-sheet': 'src/core/bottom-sheet.js'
};

export default [
  {
    input,
    external: [],
    plugins: [resolve(), commonjs()],
    output: [
      {
        entryFileNames: (chunkInfo) => (chunkInfo.name === 'main' ? 'index.esm.js' : '[name].esm.js'),
        dir: 'dist',
        format: 'esm',
        sourcemap: true,
        preserveEntrySignatures: 'strict'
      },
      {
        entryFileNames: (chunkInfo) => (chunkInfo.name === 'main' ? 'index.cjs.js' : '[name].cjs.js'),
        dir: 'dist',
        format: 'cjs',
        sourcemap: true,
        exports: 'named',
        preserveEntrySignatures: 'strict'
      }
    ],
    preserveEntrySignatures: 'strict'
  },
  {
    input: 'src/index.js',
    plugins: [resolve(), commonjs(), terser()],
    output: {
      file: 'dist/index.umd.js',
      format: 'umd',
      name: 'DOMUtilsLibrary',
      sourcemap: true
    }
  }
];