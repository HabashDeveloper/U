import resolve from '@rollup/plugin-node-resolve';
import commonjs from '@rollup/plugin-commonjs';
import json from '@rollup/plugin-json';
import esbuild from 'rollup-plugin-esbuild';
import { readFileSync } from 'fs';
import { fileURLToPath } from 'url';
import path from 'path';

// Read package.json
const __dirname = path.dirname(fileURLToPath(import.meta.url));
const pkg = JSON.parse(readFileSync(path.join(__dirname, 'package.json'), 'utf8'));

const input = 'src/index.js';
const name = 'DOMUtilsLibrary'; // global name for UMD build

export default [
  // ESM (transpiled via esbuild for fast TS/modern transforms, no minify)
  {
    input,
    external: [...Object.keys(pkg.peerDependencies || {}), /* add other externals if needed */],
    plugins: [
      resolve({ browser: true, preferBuiltins: false }),
      commonjs(),
      json(),
      esbuild({
        target: 'es2018',
        minify: false,
        jsx: 'transform'
      })
    ],
    output: {
      file: 'dist/index.esm.js',
      format: 'es',
      sourcemap: true,
      exports: 'named'
    }
  },

  // CommonJS (transpiled via esbuild)
  {
    input,
    external: [...Object.keys(pkg.peerDependencies || {}), /* add other externals if needed */],
    plugins: [
      resolve({ browser: true, preferBuiltins: false }),
      commonjs(),
      json(),
      esbuild({
        target: 'es2018',
        minify: false,
        platform: 'node',
        jsx: 'transform'
      })
    ],
    output: {
      file: 'dist/index.cjs.js',
      format: 'cjs',
      sourcemap: true,
      exports: 'named'
    }
  },

  // UMD (browser-friendly, not minified)
  {
    input,
    external: [], // if you want to exclude libs from UMD bundle, list them here
    plugins: [
      resolve({ browser: true, preferBuiltins: false }),
      commonjs(),
      json(),
      esbuild({
        target: 'es2018',
        minify: false,
        jsx: 'transform'
      })
    ],
    output: {
      file: 'dist/index.umd.js',
      format: 'umd',
      name,
      sourcemap: true,
      globals: {
        // map externals to global names if needed, e.g. 'some-lib': 'SomeLib'
      }
    }
  },

  // UMD minified (esbuild minify)
  {
    input,
    external: [],
    plugins: [
      resolve({ browser: true, preferBuiltins: false }),
      commonjs(),
      json(),
      esbuild({
        target: 'es2018',
        minify: true,
        jsx: 'transform'
      })
    ],
    output: {
      file: 'dist/index.umd.min.js',
      format: 'umd',
      name,
      sourcemap: true,
      globals: {}
    }
  }
];