# DOM Utils Library — Phase 1+2 Patch (Short README)

Resumen rápido
- Fase1:
  - Seguridad: funciones de inserción (append/prepend/before/after) tratan las cadenas como texto por defecto. Para insertar HTML explícitamente pasa { html: true } y preferiblemente un sanitizeFn.
  - Accesibilidad: Modal ahora implementa focus-trap, restaura foco, aplica aria-modal, role y aria-hidden en el fondo.
  - Compatibilidad: exporta función-fábrica DOMUtilsLibrary(selector) y alias $ para compat con versiones legacy. Añade helpers chainables (.on/.off/.once) y class/visibility helpers.
  - DOMPurify adapter (dinámico) incluido como helper (no instalado por defecto).
- Fase2:
  - Reactivity: createSignal, createEffect, createComputed mejorados con tracking y cleanup.
  - $state ahora es "signal-aware": lecturas de propiedades dentro de efectos crean dependencias y los efectos se re-ejecutan cuando las propiedades cambian.

Instalación
- Instala dependencias para tests:
  npm install --save-dev uvu jsdom

Si quieres usar sanitización con DOMPurify:
  npm install dompurify

Construir y probar
- Tests:
  npx uvu -r esm test

Notas importantes / Migración
- Strings treated as TEXT by default. To insert HTML intentionally, use:
  append(parent, htmlString, { html: true, sanitizeFn });

- For existing code that relied on implicit HTML parsing, update to pass { html: true } or use the compatibility wrapper methods.

Siguientes pasos recomendados
- Add CI (GitHub Actions) to run lint/test/build.
- Add TypeScript definitions (types) and configure package.json exports.
- Expand tests and coverage.

