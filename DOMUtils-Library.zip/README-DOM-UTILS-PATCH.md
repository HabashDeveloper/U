# DOM Utils Consolidation Patch

Generado: (ver CHANGELOG.txt)

Este archivo contiene la consolidación propuesta de la librería:
 - package.json (actualizado con "exports" y subpath ./bottom-sheet)
 - rollup.config.js (actualizado para generar index.* y bottom-sheet.*)
 - src/ (entrypoint consolidado y módulos)
 - legacy/ (copias estandarizadas de los archivos antiguos o placeholders)
 - README-DOM-UTILS-PATCH.md (este archivo)
 - CHANGELOG.txt (resumen de cambios)

Instrucciones:
1) Extrae el zip:
   unzip dom-utils-consolidation-patch.zip -d dom-utils-patch
2) Revisa los archivos en dom-utils-patch/
3) Ejecuta en la raíz:
   npm install
   npm run build
4) Si todo OK, crea branch y PR:
   git checkout -b chore/consolidate-dom-utils
   git add .
   git commit -m "chore: consolidate src and move legacy files to /legacy"
   git push origin chore/consolidate-dom-utils