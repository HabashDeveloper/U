# UPGRADE NOTES (Phase 1 & 2)

- Strings inserted via append/prepend/before/after are treated as text by default.
  Use { html: true } and sanitize user-provided HTML with DOMPurify or another sanitizer.

- Modal now traps focus and restores focus on close. It also tags background with aria-hidden while open.

- To preserve legacy behavior, use the factory:
    const $ = DOMUtilsLibrary;
    // e.g. $(selector).on('click', handler)

- $state now notifies effects when properties are read inside an effect and later changed.
  Tests included to demonstrate behavior.

