import { test } from 'uvu';
import * as assert from 'uvu/assert';

// Import reactive primitives
import { createSignal, createEffect, createComputed } from '../src/reactive/signals.js';

test('createSignal + createEffect basic reactivity and disposer', () => {
  const [get, set] = createSignal(0);
  let runs = 0;
  const disposer = createEffect(() => {
    runs++;
    // read signal to create dependency
    const v = get();
    // side-effect: no-op
    return null;
  });

  assert.is(runs, 1);
  set(1);
  assert.is(runs, 2);

  // dispose and ensure effect no longer runs
  disposer();
  set(2);
  assert.is(runs, 2);
});

test('createEffect cleanup called before re-run and on dispose', () => {
  const [get, set] = createSignal(0);
  let cleanupCalls = 0;

  const disposer = createEffect(() => {
    // effect body
    get();
    return () => { cleanupCalls++; };
  });

  // initial run -> no cleanup yet
  assert.is(cleanupCalls, 0);
  // change signal -> effect reruns and previous cleanup called
  set(1);
  assert.is(cleanupCalls, 1);
  // dispose -> cleanup called one last time
  disposer();
  assert.is(cleanupCalls, 2);
});

test('createComputed caches value and invalidates on dependency change', () => {
  const [get, set] = createSignal(2);
  const comp = createComputed(() => {
    return get() * 3;
  });

  assert.is(comp(), 6);
  set(3);
  // after set, cached should be invalidated; next call recomputes
  assert.is(comp(), 9);
});

test.run();
