import { test } from 'uvu';
import * as assert from 'uvu/assert';
import { JSDOM } from 'jsdom';

// Cada archivo de test crea y asigna su propio JSDOM para evitar interferencias
function setupDOM() {
  const dom = new JSDOM('<!doctype html><html><body></body></html>');
  global.window = dom.window;
  global.document = dom.window.document;
  global.HTMLElement = dom.window.HTMLElement;
  global.Node = dom.window.Node;
}

test('dom-utils addClass/removeClass/toggleClass and show/hide/isHidden', () => {
  setupDOM();

  // Crear el elemento de prueba de forma explícita
  const el = document.createElement('div');
  el.id = 't';
  document.body.appendChild(el);

  // Importar aquí después de haber creado el DOM global
  import('../src/utils/dom-utils.js').then((mod) => {
    const domUtils = mod.default;

    domUtils.addClass(el, 'x');
    assert.is(el.classList.contains('x'), true);

    domUtils.removeClass(el, 'x');
    assert.is(el.classList.contains('x'), false);

    domUtils.toggleClass(el, 'y');
    assert.is(el.classList.contains('y'), true);

    domUtils.hide(el);
    assert.is(domUtils.isHidden(el), true);

    domUtils.show(el);
    assert.is(domUtils.isHidden(el), false);
  });
});

test('wrapper chainable on/off and class helpers', () => {
  setupDOM();

  // Crear elemento
  const el = document.createElement('div');
  el.id = 't';
  document.body.appendChild(el);

  // Import wrapper después del setup
  return import('../src/core/wrapper.js').then((mod) => {
    const DOMUtilsCore = mod.default;

    const inst = new DOMUtilsCore('#t');

    // chain class helpers
    inst.addClass('c1').toggleClass('c2').removeClass('c1');
    assert.is(el.classList.contains('c2'), true);

    // on/off basic - direct attach
    let called = false;
    function cb() { called = true; }
    inst.on('click', cb);
    el.dispatchEvent(new window.Event('click'));
    assert.ok(called);

    // off
    inst.off('click', cb);
    called = false;
    el.dispatchEvent(new window.Event('click'));
    assert.is(called, false);
  });
});

test.run();