import { test } from 'uvu';
import * as assert from 'uvu/assert';
import { JSDOM } from 'jsdom';

// Setup global DOM for tests
const dom = new JSDOM('<!doctype html><html><body></body></html>');
global.window = dom.window;
global.document = dom.window.document;
global.HTMLElement = dom.window.HTMLElement;
global.Node = dom.window.Node;

// Import the helper we changed
import { append } from '../src/core/dom-helpers-extended.js';

test('append treats string as text by default (no HTML parsing)', () => {
  const parent = document.createElement('div');
  append(parent, '<img src=x onerror="window.__wasBad = true">');
  // textContent should contain the literal string (not parse as element)
  assert.is(parent.textContent, '<img src=x onerror="window.__wasBad = true">');
  // ensure nothing executed
  assert.ok(typeof global.window.__wasBad === 'undefined');
});

test.run();
