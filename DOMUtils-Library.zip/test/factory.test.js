import { test } from 'uvu';
import * as assert from 'uvu/assert';
import { JSDOM } from 'jsdom';

// Setup DOM
const dom = new JSDOM('<!doctype html><html><body><div class="a"></div></body></html>');
global.window = dom.window;
global.document = dom.window.document;
global.HTMLElement = dom.window.HTMLElement;
global.Node = dom.window.Node;

// Import factory
import { DOMUtilsLibrary, $ } from '../src/index.js';

test('factory $ and DOMUtilsLibrary produce instance and provide namespaces', () => {
  const inst = $(document.querySelector('.a'));
  assert.ok(inst && typeof inst.each === 'function');

  // Namespace exposure
  assert.ok(typeof DOMUtilsLibrary.gestures !== 'undefined');
  assert.ok(typeof DOMUtilsLibrary.ajax !== 'undefined');
  assert.ok(typeof DOMUtilsLibrary.utils !== 'undefined');
});

test.run();
