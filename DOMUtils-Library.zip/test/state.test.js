import { test } from 'uvu';
import * as assert from 'uvu/assert';
import { JSDOM } from 'jsdom';

// Setup DOM-like globals (not strictly needed but keeps environment consistent)
const dom = new JSDOM('<!doctype html><html><body></body></html>');
global.window = dom.window;
global.document = dom.window.document;

// Import reactive primitives
import { $state, createEffect } from '../src/reactive/signals.js';

test(' $state participates in dependency tracking: effect re-runs when property changes', () => {
  const state = $state({ count: 1 });
  let runs = 0;
  const disposer = createEffect(() => {
    runs++;
    // read property to establish dependency
    const v = state.count;
  });

  assert.is(runs, 1);
  state.count = 2;
  assert.is(runs, 2);

  // deleting property triggers re-run
  delete state.count;
  assert.is(runs, 3);

  disposer();
  // after dispose, mutating property shouldn't increase runs
  state.count = 5;
  assert.is(runs, 3);
});

test.run();
