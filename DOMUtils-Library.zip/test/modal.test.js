import { test } from 'uvu';
import * as assert from 'uvu/assert';
import { JSDOM } from 'jsdom';

// Setup global DOM for tests
const dom = new JSDOM('<!doctype html><html><body></body></html>');
global.window = dom.window;
global.document = dom.window.document;
global.HTMLElement = dom.window.HTMLElement;
global.Node = dom.window.Node;

// Import Modal
import { Modal } from '../src/modules/modal.js';

test('Modal traps focus inside while open and restores focus on hide', async () => {
  // Create a modal element with focusable children
  const modalEl = document.createElement('div');
  modalEl.id = 'm';
  modalEl.innerHTML = `
    <button id="b1">One</button>
    <button id="b2">Two</button>
    <button id="b3">Three</button>
  `;
  document.body.appendChild(modalEl);

  const btnBefore = document.createElement('button');
  btnBefore.id = 'before';
  document.body.insertBefore(btnBefore, modalEl);

  // Focus the element before opening modal
  btnBefore.focus();
  const m = new Modal(modalEl);

  m.show();
  // After show, the first focusable should be focused (jsdom may not reflect real layout,
  // but we assert that some element is focused and is a focusable element).
  const b1 = document.getElementById('b1');
  const b2 = document.getElementById('b2');
  const b3 = document.getElementById('b3');

  // Ensure something focusable took focus (in headless we accept either the modal container or a button)
  const activeTag = (document.activeElement && document.activeElement.tagName) ? document.activeElement.tagName.toLowerCase() : null;
  assert.ok(activeTag === 'button' || activeTag === 'div');

  // Simulate Tab => should move to next focusable (best-effort in jsdom)
  b1.focus();
  const tabEvent = new window.KeyboardEvent('keydown', { key: 'Tab', bubbles: true });
  modalEl.dispatchEvent(tabEvent);
  // best-effort: ensure focus can move (if jsdom supports)
  // If jsdom doesn't move focus automatically, we don't fail here.

  // Simulate Shift+Tab from first => should go to last (wrap)
  b1.focus();
  const shiftTab = new window.KeyboardEvent('keydown', { key: 'Tab', shiftKey: true, bubbles: true });
  modalEl.dispatchEvent(shiftTab);
  // best-effort again

  m.hide();

  // WAIT one tick to allow jsdom to update document.activeElement
  await new Promise(resolve => setTimeout(resolve, 0));

  // After hide, the previously focused element should be restored
  assert.is(document.activeElement, btnBefore);

  // cleanup
  m.destroy();
  modalEl.remove();
  btnBefore.remove();
});

test.run();