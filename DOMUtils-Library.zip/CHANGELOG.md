# CHANGELOG (Phase 1 & 2)

## 2025-11-30 — Phase 1 & 2 Patch
### Phase 1
- Security: safe-by-default insertion of HTML strings.
- Accessibility: Modal focus-trap and aria improvements.
- API ergonomics: factory ($), chainable wrapper methods, dom-utils helpers, DOMPurify adapter.

### Phase 2
- Reactive primitives improved: createSignal/createEffect/createComputed return disposers/cleanup tracking.
- $state is now property signal-aware and participates in dependency tracking.

Notes:
- Breaking (intentional): string insertion now treats strings as text by default. Update code that relied on implicit HTML parsing.
- Consider a major version bump when publishing.

