// Compatibility re-export for ajax APIs (consolidated)
// This file keeps backwards-compatible import path `src/ajax` while delegating to the new modules/ajax.js

export * from '../modules/ajax.js';
export { default } from '../modules/ajax.js';